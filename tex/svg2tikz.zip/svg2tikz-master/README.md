*This project is not under active development.*

# SVG2TikZ

SVG2TikZ, formally known as Inkscape2TikZ ,are a set of tools for converting SVG graphics to TikZ/PGF code. 
This project is licensed under the GNU GPL  (see  the [LICENSE](/LICENSE) file).

More documentation can be found in the [docs/](/docs/index.rst) directory.
