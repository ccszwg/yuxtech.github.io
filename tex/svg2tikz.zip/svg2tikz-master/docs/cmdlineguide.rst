Command line guide
==================

