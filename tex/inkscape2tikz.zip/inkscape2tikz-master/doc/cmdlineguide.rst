Command line guide
==================

